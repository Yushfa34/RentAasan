import { Home } from "lucide-react";

export function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground">
        <Home className="size-5" />
      </div>
      <span className="text-lg font-bold tracking-tight">
        Rent<span className="text-success">Aasan</span>
      </span>
    </div>
  );
}
