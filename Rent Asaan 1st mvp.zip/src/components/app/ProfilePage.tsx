import { useState } from 'react';
import { useMe } from '@/hooks/use-me';
import { updateProfile } from '@/lib/api';
import { PageHeader, Panel, Field } from './ui-kit';
import { Action } from './Action';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useNavigate } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
export function ProfilePage() { const me = useMe(); const navigate = useNavigate(); const qc = useQueryClient(); const [name, setName] = useState(me.profile?.full_name ?? ''); const [phone, setPhone] = useState(me.profile?.phone ?? ''); return <><PageHeader title="My profile" subtitle="Keep your account details up to date." /><Panel className="max-w-xl"><div className="space-y-5"><Field label="Full name"><Input value={name} onChange={e => setName(e.target.value)} /></Field><Field label="Phone number"><Input value={phone} onChange={e => setPhone(e.target.value)} /></Field><Field label="Email address"><Input value={me.user.email ?? ''} disabled /></Field><Field label="Account type"><Input value={me.role === 'landlord' ? 'Landlord' : 'Tenant'} disabled /></Field><Action disabled={!name.trim()} run={() => updateProfile(me.user.id, { full_name: name.trim(), phone: phone.trim() })}>Save changes</Action></div></Panel><div className="mt-8"><Button variant="outline" onClick={async () => { await qc.cancelQueries(); qc.clear(); await supabase.auth.signOut(); navigate({ to: '/auth', replace: true }); }}>Log out</Button></div></>; }
