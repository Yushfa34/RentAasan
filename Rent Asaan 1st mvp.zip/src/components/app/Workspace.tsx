import { Suspense, type ReactNode } from 'react';
import { Building2, CircleUserRound, ClipboardList, FileText, Home, MessageSquareMore, Users, Wallet } from 'lucide-react';
import { useMe } from '@/hooks/use-me';
import { AppShell, type NavItem } from './AppShell';
import { ListSkeleton } from './ui-kit';

const landlordNav: NavItem[] = [
  { to: '/dashboard', label: 'Overview', icon: Home, exact: true },
  { to: '/properties', label: 'Properties', icon: Building2 },
  { to: '/tenants', label: 'Tenants', icon: Users },
  { to: '/rent', label: 'Rent', icon: Wallet },
];
const tenantNav: NavItem[] = [
  { to: '/my-home', label: 'Home', icon: Home, exact: true },
  { to: '/my-rent', label: 'Rent', icon: Wallet },
  { to: '/documents', label: 'Documents', icon: FileText },
  { to: '/my-complaints', label: 'Requests', icon: ClipboardList },
];
export function Workspace({ children, role }: { children: ReactNode; role: 'landlord' | 'tenant' }) {
  return <Suspense fallback={<div className="mx-auto max-w-5xl p-8"><ListSkeleton /></div>}><WorkspaceInner role={role}>{children}</WorkspaceInner></Suspense>;
}
function WorkspaceInner({ children, role }: { children: ReactNode; role: 'landlord' | 'tenant' }) {
  const me = useMe();
  if (me.role !== role) return <div className="mx-auto max-w-lg p-10 text-center"><h1 className="text-2xl font-bold">This page is for {role}s</h1><p className="mt-2 text-muted-foreground">Switch to your account home to continue.</p><a className="mt-5 inline-block text-primary underline" href={me.role === 'landlord' ? '/dashboard' : '/my-home'}>Go to my home</a></div>;
  return <AppShell nav={role === 'landlord' ? landlordNav : tenantNav} desktopExtra={role === 'landlord' ? [{ to: '/complaints', label: 'Complaints', icon: MessageSquareMore }, { to: '/profile', label: 'Profile', icon: CircleUserRound }] : [{ to: '/new-complaint', label: 'New complaint', icon: MessageSquareMore }, { to: '/profile', label: 'Profile', icon: CircleUserRound }]}>{children}</AppShell>;
}
