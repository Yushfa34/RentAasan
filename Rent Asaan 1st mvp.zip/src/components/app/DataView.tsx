import { useQuery } from '@tanstack/react-query';
import { ErrorState, ListSkeleton } from './ui-kit';
export function DataView<T>({ keyName, load, children }: { keyName: string; load: () => Promise<T>; children: (data: T) => React.ReactNode }) {
  const { data, isLoading, error } = useQuery({ queryKey: [keyName], queryFn: load });
  if (isLoading) return <ListSkeleton />;
  if (error) return <ErrorState error={error} />;
  return <>{data !== undefined && children(data)}</>;
}
