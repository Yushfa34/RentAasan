import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Button, type ButtonProps } from '@/components/ui/button';
import { errMsg } from '@/lib/format';
export function Action({ run, children, done, ...props }: Omit<ButtonProps, 'onClick'> & { run: () => Promise<unknown>; done?: () => void }) {
  const [busy, setBusy] = useState(false);
  const qc = useQueryClient();
  return <Button {...props} disabled={busy || props.disabled} onClick={async () => { setBusy(true); try { await run(); await qc.invalidateQueries(); toast.success('Saved successfully'); done?.(); } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); } }}>{busy ? 'Saving…' : children}</Button>;
}
