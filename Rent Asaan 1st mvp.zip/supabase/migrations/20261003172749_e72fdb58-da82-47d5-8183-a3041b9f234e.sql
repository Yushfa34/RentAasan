create type public.app_role as enum ('landlord', 'tenant');

create table public.profiles (
  id uuid primary key,
  full_name text not null default '',
  phone text,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "read own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create table public.properties (
  id uuid primary key default gen_random_uuid(),
  landlord_id uuid not null default auth.uid(),
  name text not null check (char_length(name) between 1 and 120),
  type text not null default 'House' check (type in ('House','Portion','Apartment','Room','Shop','Commercial','Other')),
  address text not null default '',
  description text not null default '',
  units integer not null default 1 check (units >= 0 and units <= 1000),
  status text not null default 'Occupied' check (status in ('Occupied','Vacant','Partially Occupied','Under Maintenance')),
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.properties to authenticated;
grant all on public.properties to service_role;
alter table public.properties enable row level security;

create table public.tenants (
  id uuid primary key default gen_random_uuid(),
  landlord_id uuid not null default auth.uid(),
  property_id uuid not null references public.properties(id) on delete restrict,
  user_id uuid,
  full_name text not null check (char_length(full_name) between 1 and 120),
  phone text not null default '',
  email text,
  cnic text,
  unit text not null default '',
  monthly_rent numeric(12,2) not null default 0 check (monthly_rent >= 0),
  due_day integer not null default 5 check (due_day between 1 and 28),
  status text not null default 'Active' check (status in ('Active','Inactive')),
  created_at timestamptz not null default now()
);
create index on public.tenants(landlord_id);
create index on public.tenants(user_id);
create index on public.tenants(lower(email));
grant select, insert, update, delete on public.tenants to authenticated;
grant all on public.tenants to service_role;
alter table public.tenants enable row level security;

create or replace function public.my_tenant_ids()
returns setof uuid language sql stable security definer set search_path = public as $$
  select id from public.tenants where user_id = auth.uid()
$$;

create or replace function public.landlord_owns_tenant(_tenant uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.tenants where id = _tenant and landlord_id = auth.uid())
$$;

create or replace function public.my_property_ids()
returns setof uuid language sql stable security definer set search_path = public as $$
  select property_id from public.tenants where user_id = auth.uid()
$$;

create or replace function public.my_landlord_ids()
returns setof uuid language sql stable security definer set search_path = public as $$
  select landlord_id from public.tenants where user_id = auth.uid()
$$;

create or replace function public.my_tenant_user_ids()
returns setof uuid language sql stable security definer set search_path = public as $$
  select user_id from public.tenants where landlord_id = auth.uid() and user_id is not null
$$;

create policy "landlord manages properties" on public.properties for all to authenticated
  using (landlord_id = auth.uid()) with check (landlord_id = auth.uid() and public.has_role(auth.uid(),'landlord'));
create policy "tenant reads own property" on public.properties for select to authenticated
  using (id in (select public.my_property_ids()));

create policy "landlord manages tenants" on public.tenants for all to authenticated
  using (landlord_id = auth.uid()) with check (landlord_id = auth.uid() and public.has_role(auth.uid(),'landlord'));
create policy "tenant reads self" on public.tenants for select to authenticated using (user_id = auth.uid());

create policy "read own profile" on public.profiles for select to authenticated using (id = auth.uid());
create policy "update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "tenant reads landlord profile" on public.profiles for select to authenticated
  using (id in (select public.my_landlord_ids()));
create policy "landlord reads linked tenant profiles" on public.profiles for select to authenticated
  using (id in (select public.my_tenant_user_ids()));

create or replace function public.tenants_before_write()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.properties where id = new.property_id and landlord_id = new.landlord_id) then
    raise exception 'Property does not belong to you';
  end if;
  new.email := nullif(lower(trim(new.email)), '');
  if tg_op = 'UPDATE' and new.email is distinct from old.email then
    new.user_id := null;
  end if;
  if new.user_id is null and new.email is not null then
    select u.id into new.user_id from auth.users u
      join public.user_roles r on r.user_id = u.id and r.role = 'tenant'
      where lower(u.email) = new.email limit 1;
  end if;
  return new;
end $$;
create trigger tenants_before_write before insert or update on public.tenants
  for each row execute function public.tenants_before_write();

create table public.rent_records (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  landlord_id uuid not null default auth.uid(),
  period date not null,
  amount numeric(12,2) not null check (amount >= 0),
  due_date date not null,
  status text not null default 'due' check (status in ('due','paid')),
  paid_at timestamptz,
  method text check (method in ('Cash','Bank','JazzCash','Easypaisa','Other')),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, period)
);
grant select, insert, update, delete on public.rent_records to authenticated;
grant all on public.rent_records to service_role;
alter table public.rent_records enable row level security;
create policy "landlord manages rent" on public.rent_records for all to authenticated
  using (landlord_id = auth.uid()) with check (landlord_id = auth.uid());
create policy "tenant reads own rent" on public.rent_records for select to authenticated
  using (tenant_id in (select public.my_tenant_ids()));

create table public.agreements (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null unique references public.tenants(id) on delete cascade,
  landlord_id uuid not null default auth.uid(),
  property_id uuid references public.properties(id) on delete set null,
  file_path text not null,
  file_name text not null,
  uploaded_at timestamptz not null default now()
);
grant select, insert, update, delete on public.agreements to authenticated;
grant all on public.agreements to service_role;
alter table public.agreements enable row level security;
create policy "landlord manages agreements" on public.agreements for all to authenticated
  using (landlord_id = auth.uid()) with check (landlord_id = auth.uid());
create policy "tenant reads own agreement" on public.agreements for select to authenticated
  using (tenant_id in (select public.my_tenant_ids()));

create table public.deposits (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null unique references public.tenants(id) on delete cascade,
  landlord_id uuid not null default auth.uid(),
  amount numeric(12,2) not null default 0 check (amount >= 0),
  status text not null default 'Received' check (status in ('Received','Returned')),
  received_on date,
  returned_on date,
  notes text,
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.deposits to authenticated;
grant all on public.deposits to service_role;
alter table public.deposits enable row level security;
create policy "landlord manages deposits" on public.deposits for all to authenticated
  using (landlord_id = auth.uid()) with check (landlord_id = auth.uid());
create policy "tenant reads own deposit" on public.deposits for select to authenticated
  using (tenant_id in (select public.my_tenant_ids()));

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  landlord_id uuid not null default auth.uid(),
  rent_record_id uuid references public.rent_records(id) on delete set null,
  channel text not null default 'whatsapp_manual',
  message text not null,
  status text not null default 'sent' check (status in ('sent','failed','pending')),
  created_at timestamptz not null default now()
);
grant select, insert, delete on public.notifications to authenticated;
grant all on public.notifications to service_role;
alter table public.notifications enable row level security;
create policy "landlord manages notifications" on public.notifications for all to authenticated
  using (landlord_id = auth.uid()) with check (landlord_id = auth.uid());
create policy "tenant reads own notifications" on public.notifications for select to authenticated
  using (tenant_id in (select public.my_tenant_ids()));

create or replace function public.enforce_tenant_landlord()
returns trigger language plpgsql security definer set search_path = public as $$
declare t_landlord uuid;
begin
  select landlord_id into t_landlord from public.tenants where id = new.tenant_id;
  if t_landlord is null or t_landlord <> new.landlord_id then
    raise exception 'Tenant does not belong to you';
  end if;
  return new;
end $$;
create trigger rr_owner before insert or update on public.rent_records for each row execute function public.enforce_tenant_landlord();
create trigger ag_owner before insert or update on public.agreements for each row execute function public.enforce_tenant_landlord();
create trigger dp_owner before insert or update on public.deposits for each row execute function public.enforce_tenant_landlord();
create trigger nt_owner before insert or update on public.notifications for each row execute function public.enforce_tenant_landlord();

create table public.maintenance_requests (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  landlord_id uuid not null,
  property_id uuid references public.properties(id) on delete set null,
  category text not null check (category in ('Plumbing','Electricity','Gas','Wall / Paint','Other')),
  title text not null check (char_length(title) between 1 and 150),
  details text not null default '' check (char_length(details) <= 2000),
  urgency text not null default 'Medium' check (urgency in ('Low','Medium','Urgent')),
  status text not null default 'Open' check (status in ('Open','In Progress','Resolved')),
  worker text,
  photos text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.maintenance_requests to authenticated;
grant all on public.maintenance_requests to service_role;
alter table public.maintenance_requests enable row level security;
create policy "landlord reads complaints" on public.maintenance_requests for select to authenticated using (landlord_id = auth.uid());
create policy "landlord updates complaints" on public.maintenance_requests for update to authenticated
  using (landlord_id = auth.uid()) with check (landlord_id = auth.uid());
create policy "tenant reads own complaints" on public.maintenance_requests for select to authenticated
  using (tenant_id in (select public.my_tenant_ids()));
create policy "tenant creates complaints" on public.maintenance_requests for insert to authenticated
  with check (tenant_id in (select public.my_tenant_ids()));

create table public.complaint_updates (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.maintenance_requests(id) on delete cascade,
  author_id uuid default auth.uid(),
  kind text not null default 'reply' check (kind in ('reply','status')),
  message text not null check (char_length(message) between 1 and 2000),
  status text,
  created_at timestamptz not null default now()
);
grant select, insert on public.complaint_updates to authenticated;
grant all on public.complaint_updates to service_role;
alter table public.complaint_updates enable row level security;
create policy "read visible complaint updates" on public.complaint_updates for select to authenticated
  using (request_id in (select id from public.maintenance_requests));
create policy "post replies" on public.complaint_updates for insert to authenticated
  with check (author_id = auth.uid() and kind = 'reply' and request_id in (select id from public.maintenance_requests));

create or replace function public.mr_before_write()
returns trigger language plpgsql security definer set search_path = public as $$
declare t record;
begin
  if tg_op = 'INSERT' then
    select * into t from public.tenants where id = new.tenant_id;
    new.landlord_id := t.landlord_id;
    new.property_id := t.property_id;
    if t.user_id is distinct from auth.uid() and t.landlord_id is distinct from auth.uid() then
      raise exception 'Not allowed';
    end if;
  else
    new.tenant_id := old.tenant_id;
    new.landlord_id := old.landlord_id;
    new.property_id := old.property_id;
    new.updated_at := now();
    if new.status is distinct from old.status then
      insert into public.complaint_updates(request_id, author_id, kind, message, status)
      values (new.id, auth.uid(), 'status', 'Status changed to ' || new.status, new.status);
    end if;
    if new.worker is distinct from old.worker and coalesce(new.worker,'') <> '' then
      insert into public.complaint_updates(request_id, author_id, kind, message)
      values (new.id, auth.uid(), 'status', 'Worker assigned: ' || new.worker);
    end if;
  end if;
  return new;
end $$;
create trigger mr_before_write before insert or update on public.maintenance_requests
  for each row execute function public.mr_before_write();

create or replace function public.mr_after_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.complaint_updates(request_id, author_id, kind, message, status)
  values (new.id, auth.uid(), 'status', 'Complaint submitted', 'Open');
  return new;
end $$;
create trigger mr_after_insert after insert on public.maintenance_requests
  for each row execute function public.mr_after_insert();

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare r public.app_role;
begin
  r := case when new.raw_user_meta_data->>'role' = 'landlord' then 'landlord'::public.app_role else 'tenant'::public.app_role end;
  insert into public.profiles(id, full_name, phone, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.raw_user_meta_data->>'phone', new.email);
  insert into public.user_roles(user_id, role) values (new.id, r);
  if r = 'tenant' then
    update public.tenants set user_id = new.id where lower(email) = lower(new.email) and user_id is null;
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.generate_monthly_rent()
returns integer language plpgsql security definer set search_path = public as $$
declare p date := date_trunc('month', current_date)::date; n integer;
begin
  if not public.has_role(auth.uid(), 'landlord') then return 0; end if;
  insert into public.rent_records(tenant_id, landlord_id, period, amount, due_date)
  select t.id, t.landlord_id, p, t.monthly_rent, p + (t.due_day - 1)
  from public.tenants t
  where t.landlord_id = auth.uid() and t.status = 'Active'
  on conflict (tenant_id, period) do nothing;
  get diagnostics n = row_count;
  return n;
end $$;

create or replace function public.load_demo_data()
returns void language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); p1 uuid; p2 uuid; t1 uuid; t2 uuid; t3 uuid;
  cur date := date_trunc('month', current_date)::date;
begin
  if not public.has_role(uid, 'landlord') then raise exception 'Only landlords'; end if;
  insert into properties(landlord_id,name,type,address,description,units,status)
    values (uid,'UET Housing Society','House','Street 4, UET Housing Society, Lahore','Double-storey house split into rooms',4,'Occupied') returning id into p1;
  insert into properties(landlord_id,name,type,address,description,units,status)
    values (uid,'Gulberg Property','Portion','Main Boulevard, Gulberg III, Lahore','Upper and lower portions',2,'Partially Occupied') returning id into p2;
  insert into tenants(landlord_id,property_id,full_name,phone,email,cnic,unit,monthly_rent,due_day)
    values (uid,p1,'Ali Raza','03001234567','ali.raza@example.com','35202-1234567-1','Room 2B',28000,5) returning id into t1;
  insert into tenants(landlord_id,property_id,full_name,phone,email,cnic,unit,monthly_rent,due_day)
    values (uid,p2,'Sara Khan','03111234567','sara.khan@example.com','35202-7654321-2','Portion A',25000,1) returning id into t2;
  insert into tenants(landlord_id,property_id,full_name,phone,email,cnic,unit,monthly_rent,due_day)
    values (uid,p1,'Hassan Ahmed','03211234567','hassan.ahmed@example.com','35202-1112223-3','Room 1A',30000,10) returning id into t3;
  insert into deposits(tenant_id,landlord_id,amount,status,received_on) values
    (t1,uid,56000,'Received',cur - 180),(t2,uid,50000,'Received',cur - 300),(t3,uid,60000,'Received',cur - 90);
  insert into rent_records(tenant_id,landlord_id,period,amount,due_date,status,paid_at,method) values
    (t1,uid,(cur - interval '2 month')::date,28000,(cur - interval '2 month')::date + 4,'paid',(cur - interval '2 month')::date + 3,'Cash'),
    (t1,uid,(cur - interval '1 month')::date,28000,(cur - interval '1 month')::date + 4,'paid',(cur - interval '1 month')::date + 4,'JazzCash'),
    (t1,uid,cur,28000,cur + 4,'paid',now(),'Bank'),
    (t2,uid,(cur - interval '1 month')::date,25000,(cur - interval '1 month')::date,'paid',(cur - interval '1 month')::date + 1,'Easypaisa'),
    (t2,uid,cur,25000,cur,'paid',now(),'Cash'),
    (t3,uid,(cur - interval '1 month')::date,30000,(cur - interval '1 month')::date + 9,'paid',(cur - interval '1 month')::date + 12,'Cash'),
    (t3,uid,cur,30000,cur + 9,'due',null,null);
  insert into maintenance_requests(tenant_id,landlord_id,category,title,details,urgency,status) values
    (t1,uid,'Plumbing','Water leakage in bathroom','Water is leaking from the pipe under the sink.','Urgent','In Progress'),
    (t3,uid,'Electricity','Light not working in hall','The main hall light stopped working yesterday.','Medium','Open'),
    (t2,uid,'Gas','Gas pressure is low','Gas pressure in the kitchen is very low in the mornings.','Medium','Open'),
    (t2,uid,'Wall / Paint','Wall seepage in bedroom','Damp patches appearing on the bedroom wall.','Low','Resolved');
end $$;

revoke execute on function public.generate_monthly_rent() from anon, public;
revoke execute on function public.load_demo_data() from anon, public;
grant execute on function public.generate_monthly_rent() to authenticated;
grant execute on function public.load_demo_data() to authenticated;

create policy "landlord writes agreements" on storage.objects for insert to authenticated
  with check (bucket_id = 'agreements' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "landlord updates agreements" on storage.objects for update to authenticated
  using (bucket_id = 'agreements' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "landlord deletes agreements" on storage.objects for delete to authenticated
  using (bucket_id = 'agreements' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "read agreements" on storage.objects for select to authenticated
  using (bucket_id = 'agreements' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or (storage.foldername(name))[2] in (select id::text from public.my_tenant_ids() as id)));

create policy "tenant uploads complaint photos" on storage.objects for insert to authenticated
  with check (bucket_id = 'complaint-photos' and (storage.foldername(name))[1] in (select id::text from public.my_tenant_ids() as id));
create policy "read complaint photos" on storage.objects for select to authenticated
  using (bucket_id = 'complaint-photos' and (
    (storage.foldername(name))[1] in (select id::text from public.my_tenant_ids() as id)
    or exists (select 1 from public.tenants t where t.id::text = (storage.foldername(name))[1] and t.landlord_id = auth.uid())));