<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep account-scoped data operations in the imported `src/lib/api.ts` layer and use the managed authenticated route gate for signed-in pages; this preserves database access rules and avoids duplicating auth checks.
- Keep landlord and tenant navigation in a shared workspace shell while giving each task its own route; this keeps mobile navigation consistent and pages shareable.
